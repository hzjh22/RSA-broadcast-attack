from Crypto.Util.number import getPrime, bytes_to_long

E = 127


def get_m():
    with open('/flag', 'r', encoding='utf-8') as f:
        flag = f.read().strip()
    if not flag:
        raise ValueError('flag file is empty')
    return bytes_to_long(flag.encode())


def enc():
    m = get_m()
    p = getPrime(512)
    q = getPrime(512)
    n = p * q
    c = pow(m, E, n)
    print(f"n={n}")
    print(f"c={c}")


def main():
    while True:
        try:
            raw = input('input> ').strip()
        except EOFError:
            break

        if not raw:
            continue

        try:
            opt = int(raw)
        except ValueError:
            print('invalid option')
            continue

        if opt == 1:
            try:
                enc()
            except Exception:
                print('server error')
                break
        else:
            print('bye')
            break


if __name__ == '__main__':
    main()
